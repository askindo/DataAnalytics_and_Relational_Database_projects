CREATE SCHEMA IF NOT EXISTS `healthyagingllc`;

CREATE TABLE IF NOT EXISTS `patient` (
  `Patient_ID` int NOT NULL AUTO_INCREMENT,
  `Patient_FirstName` varchar(50) NOT NULL,
  `Patient_LastName` varchar(50) NOT NULL,
  `Patient_Address` varchar(100) DEFAULT NULL,
  `Patient_City` varchar(50) DEFAULT NULL,
  `Patient_Zip` varchar(8) DEFAULT NULL,
  `Patient_Phone` varchar(20) NOT NULL,
  `Patient_Insurance` varchar(50) NOT NULL,
  PRIMARY KEY (`Patient_ID`)
);

CREATE TABLE IF NOT EXISTS `provider` (
  `Provider_ID` int NOT NULL AUTO_INCREMENT,
  `Provider_Name` varchar(100) NOT NULL,
  `Provider_Zip` varchar(8) NOT NULL,
  `Provider_Phone` varchar(20) NOT NULL,
  `Provider_Owner` varchar(100) DEFAULT NULL,
  `Care_Rating` int NOT NULL DEFAULT '2',
  `Accepting_New_Patients` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Provider_ID`)
);

CREATE TABLE `service` (
  `Service_ID` int NOT NULL AUTO_INCREMENT,
  `Service_Name` varchar(100) NOT NULL,
  PRIMARY KEY (`Service_ID`)
);

CREATE TABLE IF NOT EXISTS `patient_service` (
  `Patient_ID` int NOT NULL,
  `Service_ID` int NOT NULL,
  `Patient_Service_ID` int NOT NULL,
  PRIMARY KEY (`Patient_Service_ID`),
  FOREIGN KEY (`Patient_ID`) REFERENCES `patient` (`Patient_ID`),
  FOREIGN KEY (`Service_ID`) REFERENCES `service` (`Service_ID`)
);

CREATE TABLE IF NOT EXISTS `provider_insurance` (
  `Provider_ID` int NOT NULL,
  `Insurance` varchar(100) NOT NULL,
  PRIMARY KEY (`Provider_ID`,`Insurance`),
  FOREIGN KEY (`Provider_ID`) REFERENCES `provider` (`Provider_ID`)
);

CREATE TABLE IF NOT EXISTS `provider_service` (
  `Provider_ID` int NOT NULL,
  `Service_ID` int NOT NULL,
  `Provider_Service_ID` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Provider_Service_ID`),
  FOREIGN KEY (`Provider_ID`) REFERENCES `provider` (`Provider_ID`),
  FOREIGN KEY (`Service_ID`) REFERENCES `service` (`Service_ID`)
);

CREATE TABLE `provider_patient_service` (
  `Provider_Service_ID` int NOT NULL,
  `Patient_Service_ID` int NOT NULL,
  PRIMARY KEY (`Provider_Service_ID`,`Patient_Service_ID`),
  FOREIGN KEY (`Patient_Service_ID`) REFERENCES `patient_service` (`Patient_Service_ID`),
  FOREIGN KEY (`Provider_Service_ID`) REFERENCES `provider_service` (`Provider_Service_ID`)
);




