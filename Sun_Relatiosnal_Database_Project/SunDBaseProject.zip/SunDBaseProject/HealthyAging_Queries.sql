/* 1. Generate a list of providers that have a minimum care rating of 3. 
 Show the ID, name, phone number, address, and insurance of each provider. */
SELECT pr.Provider_ID, pr.Provider_Name, pr.Provider_Phone, pr.Provider_Zip, pr.Care_Rating 
FROM Provider pr 
 	  INNER JOIN Provider_Insurance pri ON pr.Provider_ID = pri.Provider_ID
WHERE pr.Care_Rating >= 3;

/* 2. Generate a list of patients whose last name begins with the letter “D” in the city of Lumberton utilizing Home Health services. 
Show the ID and name of each patient, also show the city and service name in the results. 
Sort the list of customers descending by patient name, city, and service name. */
SELECT pa.Patient_FirstName, pa.Patient_LastName, pa.Patient_City, s.Service_Name
FROM Patient pa 
	INNER JOIN Patient_Service pas ON pa.Patient_ID = pas.Patient_ID
    INNER JOIN Service s ON pas.Service_ID = s.Service_ID
WHERE pa.Patient_LastName LIKE "D%" AND pa.Patient_City = "LUMBERTON" AND s.Service_Name = "Home Health"
ORDER BY pa.Patient_LastName, pa.Patient_FirstName, pa.Patient_City, s.Service_Name;

/* 3. Generate a list of patients getting Physical Therapy. Show the patient’s name, phone number, and city.
Order by name, city, and service. */
SELECT pa.Patient_FirstName, pa.Patient_LastName, pa.Patient_City
FROM Patient pa 
	INNER JOIN Patient_Service pas ON pa.Patient_ID = pas.Patient_ID
    INNER JOIN Provider_Patient_Service pps ON pas.Patient_Service_ID = pps.Patient_Service_ID
    INNER JOIN Provider_Service prs ON pps.Provider_Service_ID = prs.Provider_Service_ID
    INNER JOIN Provider pr ON prs.Provider_ID = pr.Provider_ID
    INNER JOIN Service s ON prs.Service_ID = s.Service_ID 
WHERE s.Service_Name = "Physical Therapy"
ORDER BY pa.Patient_LastName, pa.Patient_FirstName, pa.Patient_City, s.Service_Name;

/* 4. Generate a list of patients that are under the care of Nexus Home Health, INC. 
Show the patient name, vity, and phone number, and list the provider name in the results. Order by name and city. */
SELECT pa.Patient_FirstName, pa.Patient_LastName, pa.Patient_City, pa.Patient_Phone, pr.Provider_Name
FROM Patient pa 
	INNER JOIN Patient_Service pas ON pa.Patient_ID = pas.Patient_ID
    INNER JOIN Provider_Patient_Service pps ON pas.Patient_Service_ID = pps.Patient_Service_ID
    INNER JOIN Provider_Service prs ON pps.Provider_Service_ID = prs.Provider_Service_ID
    INNER JOIN Provider pr ON prs.Provider_ID = pr.Provider_ID
WHERE pr.Provider_Name = "NEXUS HOME HEALTH, INC"
ORDER BY pa.Patient_LastName, pa.Patient_FirstName, pa.Patient_City;

/* 5. Generate a list of the average ratings of providers group by insurance type and service name; 
then filter the groups to only show those that are "above average" (care rating better than 2.5). 
In other words, what combination of insurance types and services offer the best care.
Show the insurance type, service name, average care rating, grouped by insruance and service, 
ordered by insurance and service. */
SELECT pi.Insurance, s.Service_Name, AVG(pr.Care_Rating) AS Average_Rating
FROM Provider pr 
	INNER JOIN Provider_Insurance pi ON pr.Provider_ID = pi.Provider_ID
    INNER JOIN Provider_Service ps ON pr.Provider_ID = ps.Provider_ID
    INNER JOIN Service s ON ps.Service_ID = s.Service_ID
GROUP BY pi.Insurance, s.Service_Name
HAVING Average_Rating > 2.5
ORDER BY pi.Insurance, s.Service_Name;

/* 6. Generate a list of providers who offer more than one service and are accepting new patients. 
Show the number of services they the provider offers, their name, and a list of all the insurances they accept.
Only include providers who offer more than two services, and list those who offer the most in descending order. */
SELECT COUNT(DISTINCT s.Service_ID) AS Services_Offered, pr.Provider_Name, GROUP_CONCAT(DISTINCT pi.Insurance ORDER BY pi.Insurance SEPARATOR ", ") AS Insurance_Accepted
FROM Provider pr 
	INNER JOIN Provider_Insurance pi ON pr.Provider_ID = pi.Provider_ID
    INNER JOIN Provider_Service prs ON pr.Provider_ID = prs.Provider_ID
    INNER JOIN Service s ON prs.Service_ID = s.Service_ID
WHERE pr.Accepting_New_Patients = 1
GROUP BY pr.Provider_Name
HAVING Services_Offered > 2
ORDER BY Services_Offered DESC, pr.Provider_Name;

/* 7. Generate a query to find the average quality rating for providers in a given region (region, defining region as grouped zip codes). 
Show average rating of the providers, number of providers, and the the zip, order by rating and zip. */
SELECT AVG(pr.Care_Rating) AS Average_Rating, Count(pr.Provider_ID) As Number_Of_Providers, pr.Provider_Zip  
FROM Provider pr
WHERE pr.Provider_Zip LIKE "36%"
GROUP BY pr.Provider_Zip 
ORDER BY Average_Rating DESC, pr.Provider_Zip;

/* 8. Generate a list of providers offering nursing services with a quality rating above 4 stars. 
Sort list by highest rating and show provider name, zip, the service name and rating. */
SELECT pr.Provider_Name, pr.Provider_Zip, s.Service_Name, pr.Care_Rating
FROM Provider pr
	INNER JOIN Provider_Service ps ON pr.Provider_ID = ps.Provider_ID
    INNER JOIN Service s ON ps.Service_ID = s.Service_ID
WHERE s.Service_Name = "Nursing" AND pr.Care_Rating >= 4
ORDER BY Care_Rating DESC, pr.Provider_Zip, Provider_Name;

/* 9. Generate a list of patients seeking services in Dayton. Show patient name and the service they want (include city name with results) 
Sort the list of patients descending by last name */
SELECT pa.Patient_FirstName, pa.Patient_LastName, pa.Patient_City, s.Service_Name 
FROM Patient pa
	INNER JOIN Patient_Service pas ON pa.Patient_ID = pas.Patient_ID
    INNER JOIN Service s ON pas.Service_ID = s.Service_ID
WHERE pa.Patient_City = "Dayton"
ORDER BY pa.Patient_LastName, pa.Patient_FirstName;

/* 10. List of all Patients, their city, the services they are provided, and the provider.
Order by name, city and service. Patients with multiple services will show up more than once. */
SELECT pa.Patient_FirstName, pa.Patient_LastName, pa.Patient_City, p.Provider_Name, s.Service_Name
FROM Patient pa 
	INNER JOIN Patient_Service pas ON pa.Patient_ID = pas.Patient_ID
	INNER JOIN Provider_Patient_Service pps ON pas.Patient_Service_ID = pps.Patient_Service_ID
    INNER JOIN Provider_Service prs ON pps.Provider_Service_ID = prs.Provider_Service_ID
	INNER JOIN Provider p ON prs.Provider_ID = p.Provider_ID
    INNER JOIN Service s ON pas.Service_ID = s.Service_ID
ORDER BY pa.Patient_LastName, pa.Patient_FirstName, pa.Patient_City, s.Service_Name

/* ***** Notes on Data Model Changes ***** (This info was also included in the report)
Three significant changes were made to the final data model as compared to our original ERD. They were the way in which 
we handled (1) insurance, (2) locations, and (3) the provider-patient relationship. Changes to (1) insurance were driven
by data considerations (and are covered in the report). Changes to (2) locations was based on the feedback that you provided 
on our ERD; we agreed with your assessment that our original configuration was overly complicated and could have led to 
redundancies in storing location data.

Changes to the (3) provider-patient relationship were a bit more extensive, and upon further reflection we did not, in our initial  
development phase, give careful enough consideration to this relationship. Basically our company is in the business of matching up 
two many-to-many relationships: patient-service (a patient can request many services and a service can be used by many patients) 
and provider-service (a provider can offer many services, and a service can be offered by many providers). We originally concieved
of this as a simple task of matching patient and provider. 

But as it turned out it was a little more complex, because we weren't really matching patients and providers, but patient-service-requests 
and provider-service-offerings. To make this data model work in reality, we dropped the patient_provider table and created two intersection 
tables for the many-to-many relationships (patient_service and provider_service); we then added another intersection table (provider_patient_service) 
that holds primary key values from the other two primary intersection tables.

The solution works, and brings together all the data that we need. However, admittedly, it is not elegant. It necessitates some ungainly
JOINS. And so, while this works, with more time we could perhaps generate a better solution. That being said, it was a fun exercise
thinking through the relationship and crafting a practical resolution.
*/

